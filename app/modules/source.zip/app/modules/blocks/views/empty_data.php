<div class="col-md-12 col-sm-12 col-xs-12 data-empty text-center">
  <div class="content">
    <img class="img mb-1" src="<?=BASE?>/assets/images/ofm-nofiles.png" alt="empty">
    <div class="title">Look like there are no results in here!</div>
  </div>
</div>