<?php
// exit() ; 
// include 'code/init.php' ;

// list($inter)= dbi_fetch_row(dbi_query("SELECT * FROM intervenant WHERE inter_id = 123 ")) ; 
  
  // echo "==> $inter " ;
  require('config.php');
  if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['action']) && $_POST['action']=="dt") {
        if(isset($_POST['salarie_status']) && $_POST['salarie_status']=="all"){
            $query = "SELECT * FROM salarie c, etablissement etab where  c.etablissement_id = etab.etablissement_id  ";
        }else{
            $query = "SELECT * FROM salarie c, etablissement etab where  c.etablissement_id = etab.etablissement_id and salarie_statut = '".$_POST['salarie_status']."' ";
            
        }
        
        if(isset($_POST['etablissement_nom']) && $_POST['etablissement_nom']!="all"){
            $query .= "and etab.etablissement_nom = '".$_POST['etablissement_nom']."' ";
        }
        $result = mysqli_query($conn,$query);
        $result_arr=array();
        while($cl = mysqli_fetch_array($result)){
            $temp=array();
            $temp['salarie_id']=$cl['salarie_id'];
            $temp['salarie_nom']='<a href="profilsalarie.php?link=salarie&amp;page=aaa&amp;salarie_id='.$cl['salarie_id'].'" target="ident">'.$cl['salarie_nom'];
            $temp['salarie_adr1']=$cl['salarie_adr1'];
            $temp['salarie_cp']=$cl['salarie_cp'];
            $temp['salarie_ville']=$cl['salarie_ville'];
            $temp['etablissement_nom']=$cl['etablissement_nom'];
            $result_arr['data'][]=$temp;
        }
        echo json_encode($result_arr,true);
        exit;
    }
}
?>

<!DOCTYPE html>
<html>

<head>

  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  
<meta charset="utf-8" />
 <!-- Enregistrer le titre de la page --><title>  | SALARIES</title>
												<!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">

												<!-- Font Awesome -->
  <link rel="stylesheet" href="../plugins/fontawesome-free/css/all.min.css">
												<!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
												<!-- overlayScrollbars -->
  <link rel="stylesheet" href="../dist/css/adminlte.min.css">
												<!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
</head>

<body class="hold-transition sidebar-mini">
												<!-- Site wrapper -->
<div class="wrapper">

<!-- TOP MENU -->
  <nav class="main-header navbar navbar-expand navbar-white navbar-light">
 <!-- Menu extensible -->
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#"><i class="fas fa-bars"></i></a>
      </li>
<!-- liens TOP MENU GAUCHE-->

		<li>
		<a href="nvsalarie.php"><button type="button" class="btn btn-primary"><i class="fas fa-plus"></i> NOUVEAU SALARIE</button> 
		</li>
      
    </ul>

 <!-- liens TOP MENU DROITE -->
    <ul class="navbar-nav ml-auto">
     <!-- Placer ici l'élément à positionner à droite du TOP MENU -->
    </ul>
  
  </nav>  <!-- fin du TOP MENU -->
  
  
<!-- BARRE DE NAVIGATION -->

 <!-- Couleur et caracteristiques de la barre de navigation-->

 
<?php include('menu.php'); ?>
 
 <!-- Ne pas toucher au dessus / fin de la BARRE DE NAVIGATION-->	

 <!-- DEMARRAGE DE LA PAGE PRINCIPALE -->
  <div class="content-wrapper">
   
  <!-- TITRE DE LA PAGE PRINCIPALE A PLACE ENTRE LES BALISES H1 & ARBORESCENCE SUR LA DROITE-->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1></h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
            
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
  <!-- FIN DU TITRE DE LA PAGE PRINCIPALE A PLACE ENTRE LES BALISES H1 & ARBORESCENCE SUR LA DROITE-->
   
<?php
	// $q= dbi_query("SELECT * FROM salarie c, etablissement etab where  c.etablissement_id	= etab.etablissement_id ") ; 
        $query = "SELECT * FROM salarie c, etablissement etab where  c.etablissement_id	= etab.etablissement_id and salarie_statut = '1' ";
                $result = mysqli_query($conn,$query);
	?>
 	
    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-header">
			
            
			<div class="row">
			  <div class="col-sm-11"><h3 class="card-title"> <i class="nav-icon fas fa-user"></i> LISTE DES SALARIES</h3> </div>
			 <div class="col-sm-1"></div>
			   
            </div>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
                <div>
                    <strong>Salarie Status</strong> &nbsp;
                    <select id="salarie_status">
                        <option value="1" selected="">Salarie actifs</option>
                        <option value="0">Salarie inactifs</option>
                        <option value="all" >Tous les salarie</option>
                    </select>
                </div>
                <br/>
                <div>
                    <strong>Etablissement</strong> &nbsp;
                    <select id="etablissement_nom_selector">
                        <option value="Marseille">Marseille</option>
                        <option value="Paris">Paris</option>
                        <option value="Toulon">Toulon</option>
                        <option value="all" selected="">All</option>
                    </select>
                </div>
                <br/>
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                    <th>Nom</th>     		<!-- /.Table Client - Champs client_nom -->
                    <th>Adresse</th> 		<!-- /.Table Client - Champs client_adr1 -->
                    <th>Code Postal</th> 	<!-- /.Table Client - Champs client_cp -->
                    <th>Ville</th>	     <!-- /.Table Client - Champs client_ville -->
                    <th>Etablissement</th>	     <!-- /.Table Client - Champs client_ville -->
                    <th>N°Salarié</th>		<!-- /.Table Client - Champs client_id -->
                </tr>
                </thead>
                <tbody>
				<?php
				/*while($cl = mysqli_fetch_array($result))
				{
					?>
					<tr>
                  <td><A href="profilsalarie.php?link=salarie&amp;page=aaa&amp;salarie_id=<?=$cl['salarie_id']?>" target="ident"><?=$cl['salarie_nom'] ?></td>
                 <td><?=$cl['salarie_adr1'] ?></td>
                <td><?=$cl['salarie_cp'] ?></td>
                 <td><?=$cl['salarie_ville'] ?></td>
				 <td><?=$cl['etablissement_nom'] ?></td>
                <td><?=$cl['salarie_id'] ?></td>
                </tr>*/
					
					//<?php
					
					
				//}
				// exit(); 
				?>
                
                           
                
               
                </tbody>
                <tfoot>
                <tr>
                  <th>Nom</th>
                  <th>Adresse</th>
                  <th>Code Postal</th>
                  <th>Ville</th>
				  <th>Etablissement</th>
                  <th>N° Salarié</th>
                </tr>
                </tfoot>
              </table>
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- NE PAS TOUCHER AU DESSUS DESSOUS -->	 




<!-- DEBUT DU PIED DE PAGE -->
  
  <footer class="main-footer">
    <div class="float-right d-none d-sm-block">
      <b>Version</b> 3.0.1
    </div>
    <strong>Copyright &copy; 2019 MCPRO</strong> 
  </footer>
<!-- FIN DU PIED DE PAGE -->

<!-- NE PAS TOUCHER CI-DESSOUS -->
  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- jQuery -->
<script src="../plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="../plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- DataTables -->
<script src="../plugins/datatables/jquery.dataTables.js"></script>
<script src="../plugins/datatables-bs4/js/dataTables.bootstrap4.js"></script>
<!-- AdminLTE App -->
<script src="../dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="../dist/js/demo.js"></script>
<script>
  $(function () {
//    $("#example1").DataTable();
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
    });
    call_ajax_datatable(1,"all");
    $("#salarie_status").change(function() {
        salarie_status=$("#salarie_status").val();
        etablissement_nom=$("#etablissement_nom_selector").val();
        $('#example1').DataTable().clear().destroy();
        call_ajax_datatable(salarie_status,etablissement_nom);
    });
    $("#etablissement_nom_selector").change(function() {
        salarie_status=$("#salarie_status").val();
        etablissement_nom=$("#etablissement_nom_selector").val();
        console.log(etablissement_nom);
        $('#example1').DataTable().clear().destroy();
        call_ajax_datatable(salarie_status,etablissement_nom);
    });
    
    function call_ajax_datatable(slarie_status,etablissement_nom){
        $('#example1').DataTable( {
         "processing": true,
        "serverSide": false,
        "ajax": {
            "url": "salaries.php",
            "type": "POST",
            "data":{"action":"dt","salarie_status":slarie_status,"etablissement_nom":etablissement_nom}
        },
        "columns": [
            { "data": "salarie_nom" },
            { "data": "salarie_adr1" },
            { "data": "salarie_cp" },
            { "data": "salarie_ville" },
            { "data": "etablissement_nom" },
            { "data": "salarie_id" }
        ]
    } );
    }
  });
  
</script>
</body>
</html>
