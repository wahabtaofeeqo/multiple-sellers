<?php
// exit() ; 
include 'includes/config_tmcpro.php' ;
include 'includes/stable_functions_tmcpro.php' ;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['action']) && $_POST['action']=="dt") {
        if(isset($_POST['client_status']) && $_POST['client_status']=="all"){
            $query = "SELECT * FROM client c, etablissement etab,categorie cat where  c.etablissement_id  = etab.etablissement_id  and c.categorie_id = cat.categorie_id";
            
        }else{
            $query = "SELECT * FROM client c, etablissement etab,categorie cat where  c.etablissement_id= etab.etablissement_id and c.categorie_id = cat.categorie_id and client_statut = '".$_POST['client_status']."' ";
        }
        
        if(isset($_POST['etablissement_nom']) && $_POST['etablissement_nom']!="all"){
            $query .= "and etab.etablissement_nom = '".$_POST['etablissement_nom']."' ";
        }
        $result = mysqli_query($conn,$query);
        $result_arr=array();
        while($cl = mysqli_fetch_array($result)){
            $temp=array();
            $temp['client_id']=$cl['client_id'];
            $temp['client_nom']='<a href="profilclient.php?link=client&amp;page=aaa&amp;client_id='.$cl['client_id'].'" target="ident">'.$cl['client_nom'];
            $temp['client_adr1']=$cl['client_adr1'];
            $temp['client_cp']=$cl['client_cp'];
            $temp['client_ville']=$cl['client_ville'];
            $temp['etablissement_nom']=$cl['etablissement_nom'];
            $temp['categorie_nom']=$cl['categorie_nom'];
            $result_arr['data'][]=$temp;
        }
        echo json_encode($result_arr,true);
        exit;
    }
}
?>

<!DOCTYPE html>
<html>

<head>

  <meta http-equiv="X-UA-Compatible" content="IE=edge">
 <!-- Enregistrer le titre de la page --><title> LogMCPRO | Clients</title>
												<!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">

												<!-- Font Awesome -->
  <link rel="stylesheet" href="../plugins/fontawesome-free/css/all.min.css">
												<!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
												<!-- overlayScrollbars -->
  <link rel="stylesheet" href="../dist/css/adminlte.min.css">
												<!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
  
    <link rel="stylesheet" href="../plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- DataTables -->
  <link rel="stylesheet" href="../plugins/datatables-bs4/css/dataTables.bootstrap4.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../dist/css/adminlte.min.css">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
  
</head>

<body class="hold-transition sidebar-mini">
												<!-- Site wrapper -->
<div class="wrapper">

<!-- TOP MENU -->
  <nav class="main-header navbar navbar-expand navbar-white navbar-light">
 <!-- Menu extensible -->
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#"><i class="fas fa-bars"></i></a>
      </li>
<!-- liens TOP MENU GAUCHE-->
		<li>
		<a href="nvclient.php"><button type="button" class="btn btn-primary"><i class="fas fa-plus"></i> NOUVEAU CLIENT</button> 
		</li>
		<li>
		<a href="nvclient.php"> &nbsp <button type="button" class="btn btn-primary"></i> EXPORTER CLIENTS</button></a>
		</li>
		<li>
		&nbsp <a href="nvclient.php"> <button type="button" class="btn btn-primary"></i> CONTACTS</button></a>
		</li>
      
    </ul>

 <!-- liens TOP MENU DROITE -->
 
 
    <ul class="navbar-nav ml-auto">
     <!-- Placer ici l'élément à positionner à droite du TOP MENU -->
    </ul>
  
  </nav>  <!-- fin du TOP MENU -->
  
  
<!-- BARRE DE NAVIGATION -->


<?php include('menu.php'); ?>



 <!-- DEMARRAGE DE LA PAGE PRINCIPALE -->
  <div class="content-wrapper">
   
  <!-- TITRE DE LA PAGE PRINCIPALE A PLACE ENTRE LES BALISES H1 & ARBORESCENCE SUR LA DROITE-->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-9">
            
          </div>
          <div class="col-sm-3">
            <ol class="breadcrumb float-sm-right">
             
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
  <!-- FIN DU TITRE DE LA PAGE PRINCIPALE A PLACE ENTRE LES BALISES H1 & ARBORESCENCE SUR LA DROITE-->
   

 	<?php
	//$q= dbi_query("SELECT * FROM client c, categorie cat , etablissement etab where  c.etablissement_id	= etab.etablissement_id	 and c.categorie_id = cat.categorie_id ") ; 
	?>
    <!-- Main content -->
	
	
	
    <section class="content">
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-header">
			
            
			<div class="row">
			  <div class="col-sm-11"><h3 class="card-title"> <i class="nav-icon fas fa-user"></i> LISTE DES CLIENTS</h3> </div>
			 <div class="col-sm-1"></div>
			   
            </div>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
                <div>
                    <strong>Client Status</strong> &nbsp;
                    <select id="client_status">
                        <option value="1" selected="">Client actifs</option>
                        <option value="0">Clients inactifs</option>
                        <option value="all" >Tous les clients</option>
                    </select>
                </div>
                <br/>
                <div>
                    <strong>Etablissement</strong> &nbsp;
                    <select id="etablissement_nom_selector">
                        <option value="Marseille">Marseille</option>
                        <option value="Paris">Paris</option>
                        <option value="Toulon">Toulon</option>
                        <option value="all" selected="">All</option>
                    </select>
                </div>
                <br/>
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                    <th>Nom</th>     		<!-- /.Table Client - Champs client_nom -->
                    <th>Adresse</th> 		<!-- /.Table Client - Champs client_adr1 -->
                    <th>Code Postal</th> 	<!-- /.Table Client - Champs client_cp -->
                    <th>Ville</th>	     <!-- /.Table Client - Champs client_ville -->
                    <th>Etablissement</th>	     <!-- /.Table Client - Champs client_ville -->
                    <th>Cat&#233;gorie</th>
                    <th>N&#176; Client</th>	<!-- /.Table Client - Champs client_id -->
                </tr>
                </thead>
                <tbody>
                </tbody>
                <tfoot>
                <tr>
                  <th>Nom</th>
                  <th>Adresse</th>
                  <th>Code Postal</th>
                  <th>Ville</th>
                  <th>Etablissement</th>
                  <th>Cat&#233;gorie</th>
                    <th>N&#176; Client</th>
                </tr>
                </tfoot>
              </table>
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- NE PAS TOUCHER AU DESSUS DESSOUS -->	 




<!-- DEBUT DU PIED DE PAGE -->
  
  <footer class="main-footer">
    <div class="float-right d-none d-sm-block">
      <b>Version</b> 3.0.1
    </div>
    <strong>Copyright &copy; 2019 MCPRO</strong> 
  </footer>
<!-- FIN DU PIED DE PAGE -->

<!-- NE PAS TOUCHER CI-DESSOUS -->
  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="../plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="../plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- DataTables -->
<script src="../plugins/datatables/jquery.dataTables.js"></script>
<script src="../plugins/datatables-bs4/js/dataTables.bootstrap4.js"></script>
<!-- AdminLTE App -->
<script src="../dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="../dist/js/demo.js"></script>
<script>
  $(function () {
    //$("#example1").DataTable();
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
    });
    call_ajax_datatable(1,"all");
    $("#client_status").change(function() {
        client_status=$("#client_status").val();
        etablissement_nom=$("#etablissement_nom_selector").val();
        $('#example1').DataTable().clear().destroy();
        call_ajax_datatable(client_status,etablissement_nom);
    });
    $("#etablissement_nom_selector").change(function() {
        client_status=$("#client_status").val();
        etablissement_nom=$("#etablissement_nom_selector").val();
        console.log(etablissement_nom);
        $('#example1').DataTable().clear().destroy();
        call_ajax_datatable(client_status,etablissement_nom);
    });
    
    function call_ajax_datatable(client_status,etablissement_nom){
        $('#example1').DataTable( {
         "processing": true,
        "serverSide": false,
        "language": {
      "emptyTable": "No data available in table"
    },
        "ajax": {
            "url": "clients.php",
            "type": "POST",
            "data":{"action":"dt","client_status":client_status,"etablissement_nom":etablissement_nom}
        },
        "columns": [
            { "data": "client_nom" },
            { "data": "client_adr1" },
            { "data": "client_cp" },
            { "data": "client_ville" },
            { "data": "etablissement_nom" },
            { "data": "categorie_nom" },
            { "data": "client_id" }
        ]
    } );
    }
  });
</script>
</body>
</html>
